POKEMON SAPPHIRE MULTICART â€” ALPHA 1.1
Last updated November 6, 2026

English translation and three-part multicart by P3 with ChatGPT.
Original NES adaptation associated with Henggedianzi/Jncota.
Based on Game Freak's Pokemon Sapphire, published by Nintendo and The Pokemon Company.

Install Python 3. Extract this kit into a folder. Put your three ORIGINAL
Chinese ROMs in that same folder, named part1.nes, part2.nes, part3.nes.
Keep their headers and any trailing bytes intact.
Windows: double-click patch-windows.cmd.
macOS: open Terminal in this folder and run sh patch-macos.command
Linux: open Terminal in this folder and run sh patch-linux.sh
The script creates Pokemon-Sapphire-Alpha-1.1.nes in this folder.
It checks all source hashes and the output hash, and refuses to overwrite
an existing output. No extra Python packages are needed.

The IPS applies to the intermediate cartridge assembled by assemble.py.
Use the launcher above to construct that cartridge and apply the patch.

Requires NES 2.0 mapper 342 (CoolGirl). Tested in FCEUmm and FCEUX 2.7.0.
The selector displays Version 1.1. Each part starts with its own team,
items and save. Reset to select the next part. Use normal in-game saves.
Physical cartridge compatibility and some optional content remain untested.
See Playing-guide.txt for controls and engine differences.

Required original ROMs, SHA-256
Original filename: shen qi bao bei (c) [hengge].nes
Rename to part1.nes (1,048,592 bytes)
c50f58ca71e237011e63484dd68668b62b6d1c51ff6dfa1b326a2bc0b8635d9c
Original filename: Pokemon Diamond II (Ch) [!].nes
Rename to part2.nes (1,048,592 bytes)
6cd56148f5a8b1619daf75a453cb8e3844855d5b7cded05a0c1c7fbd38bf211f
Original filename: Pokemon Diamond III (HengGe, ABC-51PCB, MMC3 based 8M)(Ch)[!].nes
Rename to part3.nes (1,048,848 bytes)
f9d89e7e1efeef89db7ebd5226c23b1ecfba3e324f4f2230966ece2b7a4d963e

Output SHA-256
db2969709e147d2ea3867f4a455e9fc54ccbae21c0499523ec02d4a142415a6b
