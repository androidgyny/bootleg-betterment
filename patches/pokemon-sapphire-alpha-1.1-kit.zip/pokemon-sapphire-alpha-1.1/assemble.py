"""Build Pokemon Sapphire Alpha 1.1 from three original cartridges."""
from pathlib import Path
import hashlib
import json
import sys

def main():
    folder = Path(__file__).resolve().parent
    manifest = json.loads((folder / "manifest.json").read_text())
    parts = []
    for source in manifest["sources"]:
        path = folder / source["file"]
        data = path.read_bytes()
        if hashlib.sha256(data).hexdigest() != source["sha256"]:
            raise ValueError(f"{path.name} has the wrong SHA-256. See README.txt.")
        parts.append(data[16:16 + 1048576])
    result = bytearray(16 + 1048576)
    result.extend(b"".join(parts))
    patch = (folder / "sapphire.ips").read_bytes()
    if patch[:5] != b"PATCH":
        raise ValueError("Invalid patch header")
    cursor = 5
    while patch[cursor:cursor + 3] != b"EOF":
        offset = int.from_bytes(patch[cursor:cursor + 3], "big")
        size = int.from_bytes(patch[cursor + 3:cursor + 5], "big")
        cursor += 5
        if size == 0 or cursor + size > len(patch) or offset + size > len(result):
            raise ValueError("Invalid patch record")
        result[offset:offset + size] = patch[cursor:cursor + size]
        cursor += size
    if hashlib.sha256(result).hexdigest() != manifest["outputSHA256"]:
        raise ValueError("Output verification failed")
    destination = folder / manifest["output"]
    with destination.open("xb") as output:
        output.write(result)
    print(f"Created {destination.name}. SHA-256 verified.")

if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError) as error:
        print(f"Could not assemble the ROM: {error}", file=sys.stderr)
        sys.exit(1)
