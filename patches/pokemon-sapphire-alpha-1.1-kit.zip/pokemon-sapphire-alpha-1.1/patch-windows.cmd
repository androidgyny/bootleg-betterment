@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  python assemble.py
) else (
  py -3 assemble.py
)
pause
