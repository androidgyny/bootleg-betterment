FFIV Trilogy English Beta 1.1.2 - verified local release

No ROMs included. Supply the three Chinese originals listed in manifest.json.
Run: python patch.py X1.nes X2.nes X3.nes output.nes
Checksums are enforced; existing output files are never overwritten.
Output SHA256: 16266e0d38d83fdb49fd674de01879b9b8d75a3519ab492d9544dcfad07c1862
See release Validation-summary.json for the exact test scope and assists.
